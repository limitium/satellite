<div style="clear: both;"></div>
	<div class="footer">
		<a href="http://wpglamour.com/" target="_blank" class="design">&nbsp;<span>WP Glamour</span></a>
    	<div class="footertext">
			<?php bloginfo('name'); ?> is proudly powered by <a href="http://wordpress.org/">WordPress</a><br />
            <a href="<?php bloginfo('rss2_url'); ?>">Entries (RSS)</a> and <a href="<?php bloginfo('comments_rss2_url'); ?>">Comments (RSS)</a>.
			<?php wp_footer(); ?>
		</div> <!-- FOOTER -->
	</div> <!-- FOOTER TEXT-->
</div> <!-- ALL -->
</body>
</html>